<?php
/*
Plugin Name: Cotizador de Productos Woocommerce
Description: Plugin para generar cotizaciones en el administrador usando productos de WooCommerce. Permite Crear cotizaciones con nombre, email, teléfono de cliente - Agregar productos de tu woocommerce y genera cotización en PDF
Version: 1.0
Author: Cristián R. Alvarez M.
*/

// Evitar acceso directo al archivo
if (!defined('ABSPATH')) {
    exit;
}

// Incluir Dompdf
require_once plugin_dir_path(__FILE__) . 'dompdf/autoload.inc.php';

use Dompdf\Dompdf;
use Dompdf\Options;

// Crear la tabla de cotizaciones al activar el plugin
register_activation_hook(__FILE__, 'crear_tabla_cotizaciones');

function crear_tabla_cotizaciones() {
    global $wpdb;
    $tabla = $wpdb->prefix . 'cotizaciones';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $tabla (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        nombre_cliente varchar(255) NOT NULL,
        telefono_cliente varchar(20) NOT NULL,
        email_cliente varchar(255) NOT NULL,
        productos text NOT NULL,
        total varchar(100) NOT NULL,
        fecha datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

// Añadir menú en el administrador
add_action('admin_menu', 'añadir_menu_cotizador');

function añadir_menu_cotizador() {
    add_menu_page(
        'Generador de Cotizaciones', // Título de la página
        'Cotizaciones', // Título del menú
        'manage_options', // Capacidad requerida
        'generador-cotizaciones', // Slug del menú
        'mostrar_generador_cotizaciones', // Función que muestra el contenido
        'dashicons-media-text', // Ícono del menú
        6 // Posición en el menú
    );

    // Submenú para listar cotizaciones
    add_submenu_page(
        'generador-cotizaciones', // Slug del menú padre
        'Listado de Cotizaciones', // Título de la página
        'Listado', // Título del menú
        'manage_options', // Capacidad requerida
        'listado-cotizaciones', // Slug del submenú
        'mostrar_listado_cotizaciones' // Función que muestra el contenido
    );
}

// Función para mostrar el generador de cotizaciones
function mostrar_generador_cotizaciones() {
    if (!current_user_can('manage_options')) {
        return;
    }

    // Obtener productos de WooCommerce
    $productos = wc_get_products(array('status' => 'publish', 'limit' => -1));

    // Procesar el formulario
    if (isset($_POST['generar_cotizacion'])) {
        $nombre_cliente = sanitize_text_field($_POST['nombre_cliente']);
        $telefono_cliente = sanitize_text_field($_POST['telefono_cliente']);
        $email_cliente = sanitize_email($_POST['email_cliente']);
        $productos_seleccionados = $_POST['productos']; // Array de productos seleccionados
        $fecha = date('d/m/Y');

        // Calcular el total
        $total = 0;
        $productos_cotizados = array();
        foreach ($productos_seleccionados as $producto_id => $cantidad) {
            if ($cantidad > 0) { // Solo procesar si la cantidad es mayor que 0
                $producto = wc_get_product($producto_id);
                $nombre = $producto->get_name();
                $precio_unitario = $producto->get_price();
                $total_producto = $precio_unitario * $cantidad;
                $total += $total_producto;

                // Guardar detalles del producto
                $productos_cotizados[] = "{$nombre} | Cantidad: {$cantidad} | Precio Unitario: " . wc_price($precio_unitario) . " | Total: " . wc_price($total_producto);
            }
        }

  // Guardar la cotización en la base de datos
global $wpdb;
$tabla = $wpdb->prefix . 'cotizaciones';
$resultado = $wpdb->insert(
    $tabla,
    array(
        'nombre_cliente' => $nombre_cliente,
        'telefono_cliente' => $telefono_cliente,
        'email_cliente' => $email_cliente,
        'productos' => serialize($productos_cotizados), // Serializar el array
        'total' => $total,
        'fecha' => current_time('Y-m-d')
    )
);

        // Mostrar mensaje de éxito o error
        if ($resultado === false) {
            echo '<div class="error"><p>Error al guardar la cotización: ' . $wpdb->last_error . '</p></div>';
        } else {
            echo '<div class="updated"><p>Cotización guardada correctamente.</p></div>';
        }
    }

    // Mostrar el formulario
    ?>
    <div class="wrap">
        <h1>Generador de Cotizaciones</h1>
        <form method="post" action="">
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="nombre_cliente">Nombre del Cliente:</label></th>
                    <td><input type="text" name="nombre_cliente" required class="regular-text"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="telefono_cliente">Teléfono:</label></th>
                    <td><input type="text" name="telefono_cliente" required class="regular-text"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="email_cliente">Email:</label></th>
                    <td><input type="email" name="email_cliente" required class="regular-text"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="productos">Seleccionar Productos:</label></th>
                    <td>
                        <?php foreach ($productos as $producto) : ?>
                            <label>
                                <input type="number" name="productos[<?php echo $producto->get_id(); ?>]" style="width: 50px;" value="0">
                                <?php echo $producto->get_name() . ' - ' . wc_price($producto->get_price()); ?>
                            </label><br>
                        <?php endforeach; ?>
                    </td>
                </tr>
            </table>
            <p class="submit">
                <input type="submit" name="generar_cotizacion" value="Generar Cotización" class="button-primary">
            </p>
        </form>
    </div>
    <?php
}

// Función para mostrar el listado de cotizaciones
function mostrar_listado_cotizaciones() {
    if (!current_user_can('manage_options')) {
        return;
    }

    // Procesar la descarga del PDF
    if (isset($_GET['descargar_pdf']) && !empty($_GET['id'])) {
        generar_pdf_cotizacion(intval($_GET['id']));
    }

    global $wpdb;
    $tabla = $wpdb->prefix . 'cotizaciones';
    $cotizaciones = $wpdb->get_results("SELECT * FROM $tabla ORDER BY fecha DESC, id DESC");

    echo '<div class="wrap">';
    echo '<h1>Listado de Cotizaciones</h1>';
    echo '<table class="wp-list-table widefat fixed striped">';
    echo '<thead><tr><th>ID</th><th>Nombre del Cliente</th><th>Teléfono</th><th>Email</th><th>Total</th><th>Fecha</th><th>Acciones</th></tr></thead>';
    echo '<tbody>';
    foreach ($cotizaciones as $cotizacion) {
        
        
        
        echo '<tr>';
        echo '<td>' . $cotizacion->id . '</td>';
        echo '<td>' . $cotizacion->nombre_cliente . '</td>';
        echo '<td>' . $cotizacion->telefono_cliente . '</td>';
        echo '<td>' . $cotizacion->email_cliente . '</td>';
        echo '<td>' . wc_price($cotizacion->total) . '</td>';
        echo '<td>' . date("d-m-Y",strtotime($cotizacion->fecha )). '</td>';
        echo '<td><a href="' . admin_url('admin.php?page=listado-cotizaciones&descargar_pdf=1&id=' . $cotizacion->id) . '" class="button">Descargar PDF</a></td>';
        echo '</tr>';
    }
    echo '</tbody></table>';
    echo '</div>';
}

// Función para generar el PDF
function generar_pdf_cotizacion($cotizacion_id) {
    global $wpdb;
    $tabla = $wpdb->prefix . 'cotizaciones';
    $cotizacion = $wpdb->get_row($wpdb->prepare("SELECT * FROM $tabla WHERE id = %d", $cotizacion_id));

    if (!$cotizacion) {
        wp_die('Cotización no encontrada.');
    }

    // Deserializar los productos
    $productos = unserialize($cotizacion->productos);

    // Crear el contenido HTML del PDF
    $html = '
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <title>Cotización #' . $cotizacion->id . '</title>
        <style>
            body { font-family: Arial, sans-serif; font-size: 12px; }
            h1 { text-align: center; }
            table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            th, td { border: 1px solid #000; padding: 8px; text-align: left; }
            th { background-color: #f2f2f2; }
            .total { font-weight: bold; text-align: right; }
        </style>
    </head>
    <body>
    <h1>AUTOMATIZAMOS TU CASA</h1>
        <h1>Cotización #' . $cotizacion->id . '</h1>
        <table>
            <tr>
                <th>Nombre del Cliente</th>
                <td>' . $cotizacion->nombre_cliente . '</td>
            </tr>
            <tr>
                <th>Teléfono</th>
                <td>' . $cotizacion->telefono_cliente . '</td>
            </tr>
            <tr>
                <th>Email</th>
                <td>' . $cotizacion->email_cliente . '</td>
            </tr>
            <tr>
                <th>Fecha</th>
                <td>' . date("d-m-Y",strtotime($cotizacion->fecha )) . '</td>
            </tr>
        </table>

        <h2>Detalles de la Cotización</h2>
        <table>
            <thead>
                <tr>
                    <th>Producto</th>
                    <th>Cantidad</th>
                    <th>Precio Unitario</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>';

    // Mostrar cada producto en una fila de la tabla
    foreach ($productos as $producto) {
        // Extraer los detalles del producto
        
        print_r($producto);
        
        $detalles = explode(" | ", $producto);
        
        
        $nombre = $detalles[0];
        $cantidad = str_replace("Cantidad: ", "", $detalles[1]);
        $precio_unitario = str_replace("Precio Unitario: ", "", $detalles[2]);
        $total_producto = str_replace("Total: ", "", $detalles[3]);

        $html .= '
                <tr>
                    <td>' . $nombre . '</td>
                    <td>' . $cantidad . '</td>
                    <td>' . $precio_unitario . '</td>
                    <td>' . $total_producto . '</td>
                </tr>';
    }

    $html .= '
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="3" class="total">Total General</td>
                    <td>' . wc_price($cotizacion->total) . '</td>
                </tr>
            </tfoot>
        </table>
    </body>
    </html>';

    // Configurar Dompdf
    $options = new Options();
    $options->set('isHtml5ParserEnabled', true);
    $options->set('isRemoteEnabled', true);
    $options->set('defaultFont', 'Arial'); // Usar una fuente compatible

    $dompdf = new Dompdf($options);
    $dompdf->loadHtml($html, 'UTF-8'); // Forzar codificación UTF-8
    $dompdf->setPaper('A4', 'portrait');
    $dompdf->render();

    // Limpiar el búfer de salida
    ob_clean();

    // Descargar el PDF
    $dompdf->stream("cotizacion_{$cotizacion->id}.pdf", array("Attachment" => true));
    exit;
}